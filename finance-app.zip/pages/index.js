import useSWR from 'swr'
import axios from 'axios'
import { useState, useEffect } from 'react'

const fetcher = (url) => axios.get(url).then(r => r.data)

export default function Home() {
  const { data: members } = useSWR('/api/members', fetcher, { fallbackData: [] })
  const { data: payments } = useSWR('/api/payments?monthKey=' + getMonthKey(), fetcher, { fallbackData: [] })
  const [loading, setLoading] = useState(false)

  function getMonthKey() {
    const d = new Date()
    return `${d.getFullYear()}-${d.getMonth()+1}`
  }

  function payNow(memberId) {
    setLoading(true)
    axios.post('/api/payments', { memberId }).then(r => {
      alert('Payment recorded (simulated).')
      window.location.reload()
    }).catch(e => {
      alert('Error: ' + (e?.response?.data?.message || e.message))
    }).finally(() => setLoading(false))
  }

  return (
    <div className="container">
      <h1>Finance — Chit Fund</h1>
      <p>20 members · ₹5,000 due by 10th · Late fee ₹500 after 10th · Draw on 15th</p>

      <section style={{marginTop:24}}>
        <h2>Members</h2>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>Paid?</th><th>Action</th></tr></thead>
          <tbody>
            {members.map(m => {
              const p = (payments || []).find(x => x.memberId === m.id)
              return (
                <tr key={m.id} style={{borderTop:'1px solid #ddd'}}>
                  <td style={{padding:8}}>{m.id}</td>
                  <td style={{padding:8}}>{m.name}</td>
                  <td style={{padding:8}}>{m.email}</td>
                  <td style={{padding:8}}>{m.phone}</td>
                  <td style={{padding:8}}>{p?.status === 'Paid' ? `Paid ${p.amount + p.lateFee}` : 'Pending'}</td>
                  <td style={{padding:8}}><button onClick={() => payNow(m.id)} disabled={p?.status === 'Paid' || loading}>Pay Now</button></td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </section>

      <section style={{marginTop:24}}>
        <h2>Payments this month</h2>
        <table style={{width:'100%',borderCollapse:'collapse'}}>
          <thead><tr><th>Member</th><th>Amount</th><th>LateFee</th><th>Status</th></tr></thead>
          <tbody>
            {(payments || []).map(p => (
              <tr key={p.id} style={{borderTop:'1px solid #ddd'}}>
                <td style={{padding:8}}>{p.memberId}</td>
                <td style={{padding:8}}>{p.amount}</td>
                <td style={{padding:8}}>{p.lateFee}</td>
                <td style={{padding:8}}>{p.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  )
}
