import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

const seedMembers = Array.from({ length: 20 }).map((_, i) => ({
  name: `Member ${i+1}`,
  email: `member${i+1}@example.com`,
  phone: `9000000${100 + i}`
}))

export default async function handler(req, res) {
  if (req.method === 'GET') {
    const members = await prisma.member.findMany({ orderBy: { id: 'asc' } })
    if (members.length === 0) {
      // seed initial 20
      await prisma.member.createMany({ data: seedMembers })
      const fresh = await prisma.member.findMany({ orderBy: { id: 'asc' } })
      return res.json(fresh)
    }
    return res.json(members)
  }

  if (req.method === 'POST') {
    const { name, email, phone } = req.body
    const m = await prisma.member.create({ data: { name, email, phone } })
    return res.json(m)
  }

  res.status(405).end()
}
