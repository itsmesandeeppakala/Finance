import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

function getMonthKey(d = new Date()) {
  return `${d.getFullYear()}-${d.getMonth()+1}`
}

export default async function handler(req, res) {
  if (req.method === 'GET') {
    const { monthKey } = req.query
    const mk = monthKey || getMonthKey()
    const payments = await prisma.payment.findMany({ where: { monthKey: mk } })
    return res.json(payments)
  }

  if (req.method === 'POST') {
    const { memberId } = req.body
    const d = new Date()
    const deadline = new Date(d.getFullYear(), d.getMonth(), 10, 23, 59, 59)
    const lateFee = d > deadline ? 500 : 0
    const mk = getMonthKey(d)

    // If there is already a record for this member this month, update it
    const existing = await prisma.payment.findFirst({ where: { memberId: Number(memberId), monthKey: mk } })
    if (existing && existing.status === 'Paid') {
      return res.status(400).json({ message: 'Already paid' })
    }

    if (existing) {
      const up = await prisma.payment.update({
        where: { id: existing.id },
        data: { amount: 5000, lateFee, paidAt: new Date(), status: 'Paid' }
      })
      return res.json(up)
    }

    const p = await prisma.payment.create({
      data: {
        memberId: Number(memberId),
        monthKey: mk,
        amount: 5000,
        lateFee,
        paidAt: new Date(),
        status: 'Paid'
      }
    })
    return res.json(p)
  }

  res.status(405).end()
}
